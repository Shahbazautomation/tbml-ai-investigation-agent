# How to add these case studies to GitHub using Cursor

This is the exact workflow to get this `case-studies/` folder from here into your GitHub portfolio using Cursor.

## Option A — Add to your existing TBML repo (recommended)

Best if you want the case studies to sit next to the live agent they relate to (`tbml-ai-investigation-agent`).

1. Open Cursor → **File → Open Folder** → select your local clone of `tbml-ai-investigation-agent`.
   - If you don't have it cloned locally yet, open Cursor's terminal (`` Ctrl+` ``) and run:
     `git clone https://github.com/Shahbazautomation/tbml-ai-investigation-agent.git`
2. Copy this entire `case-studies/` folder (README.md, case-01/02/03.md, data/) into the root of that repo.
3. In Cursor's terminal, inside the repo folder:
   ```bash
   git add case-studies/
   git commit -m "Add synthetic financial crime case study portfolio"
   git push
   ```
4. Add a line/link to the repo's main README pointing to `case-studies/README.md` so it's discoverable.

## Option B — Create a standalone case-studies repo

Best if you want these to stand alone and link them from multiple places (portfolio site, LinkedIn, resume).

1. Create a new empty repo on GitHub, e.g. `financial-crime-case-studies` (no README/gitignore — keep it empty).
2. In Cursor: **File → Open Folder** → open this `case-studies` folder directly (rename it if you like).
3. In Cursor's terminal:
   ```bash
   git init
   git add .
   git commit -m "Initial synthetic case study portfolio"
   git branch -M main
   git remote add origin https://github.com/Shahbazautomation/financial-crime-case-studies.git
   git push -u origin main
   ```
4. Link this new repo from your `shahbazautomation.github.io` portfolio site and from the TBML repo's README.

## Either way — before you push

- **Do a final read-through** of every file for anything that could resemble a real name, employer, account number, or amount from an actual case you worked. Everything here is fabricated, but you know the real cases — you're the best check on unintended overlap.
- Do **not** add screenshots, exports, or scanned documents from real FIA systems, even redacted ones. Keep everything in this folder text-based and synthetic, generated fresh — never derived from real files.
- Once pushed, add a link to this case-studies section in the **Featured** section of your LinkedIn profile and reference it in your next "Financial Crime x AI" LinkedIn post.

## Next case studies to add later

Your project scope mentions Hundi/Hawala and TBML as your specialty — consider adding a 4th case (e.g. sanctions/PEP screening EDD escalation) once these three are live, to round out the typology coverage without overloading the portfolio.
