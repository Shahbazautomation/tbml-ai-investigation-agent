# Financial Crime Investigation — Case Study Portfolio

**Author:** Muhammad Shahbaz ul Hassan
**Background:** Financial Crime & AML/CFT Investigator, 7+ years, 300+ investigations completed (Federal Investigation Agency, Pakistan) across Hundi/Hawala networks, Trade-Based Money Laundering (TBML), terrorist financing, and banking fraud.

## Purpose of this folder

This folder contains **synthetic case studies** that demonstrate the investigative methodology, red-flag analysis, and reporting standards I apply in real financial crime casework — without disclosing any confidential, government-held, or real-person case data.

Each case study is built the same way a real Confidential Final Report (CFR) or Suspicious Transaction Report (STR) analysis would be structured under Pakistan's AML Act 2010 and FATF Recommendations, but every name, account number, company, and transaction amount below is **entirely fictional**.

> ⚠️ **DISCLAIMER — SYNTHETIC DATA**
> All entities, individuals, account numbers, transaction values, and case references in this folder are fabricated for portfolio/demonstration purposes only. Any resemblance to real persons, companies, or ongoing/closed investigations is coincidental. No confidential government information, real case files, or real subject data has been used.

## Why case studies instead of just claiming "300+ investigations"

A number on a resume isn't verifiable. These write-ups show *how I think through a case* — the red flags I'd look for, the evidence trail I'd build, the legal/regulatory framework I'd apply, and the outcome I'd document — so a recruiter or hiring manager can assess investigative competence directly, the same way they'd assess a technical portfolio.

## Case studies in this folder

| # | Case Study | Typology | Skills Demonstrated |
|---|------------|----------|----------------------|
| 01 | [Trade-Based Money Laundering](./case-01-tbml.md) | Over-invoicing via shell trading company | TBML red flags, trade document analysis, beneficial ownership tracing |
| 02 | [Hundi/Hawala Network Mapping](./case-02-hawala.md) | Informal value transfer system (IVTS) | Network/link analysis, informal remittance tracing, cross-border coordination |
| 03 | [Structuring / Smurfing STR Review](./case-03-str-structuring.md) | Deposit structuring below CTR threshold | Transaction monitoring, STR drafting, pattern analysis |

Each case includes: background, methodology, red flags, evidence/analysis (with a synthetic transaction table), outcome, and the specific skills it demonstrates — mapped to real AML/CFT job requirements.

## How this fits the rest of my portfolio

This complements my live automation project — the [TBML AI Investigation Agent](https://github.com/Shahbazautomation/tbml-ai-investigation-agent) — which applies the same TBML red-flag logic from Case Study 01 in an automated AI pipeline (n8n + Gemini). Together they show both the manual investigative expertise and the ability to encode that expertise into AI-assisted tooling.

Full portfolio: [shahbazautomation.github.io](https://shahbazautomation.github.io)
